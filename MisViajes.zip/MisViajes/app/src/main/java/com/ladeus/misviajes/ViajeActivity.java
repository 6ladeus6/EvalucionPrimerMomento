package com.ladeus.misviajes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class ViajeActivity extends AppCompatActivity {
    EditText jetCodigoViaje, jetDestino, jetCantidadPersonas, jetvalor;
    CheckBox jcbactivo;
    DBHelper admin = new DBHelper(this, "Agencia.db", null, 2);
    long resp;
    int sw;
    String codigoViaje, destino, cantidadPersonas, valor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viaje);

        //Ocultar titulo por defecto y asociar objetos Java con Xml
        getSupportActionBar().hide();
        jetCodigoViaje = findViewById(R.id.etcodviaje);
        jetDestino = findViewById(R.id.etdestino);
        jetCantidadPersonas = findViewById(R.id.etcantidadPersona);
        jetvalor = findViewById(R.id.etvalor);
        jcbactivo = findViewById(R.id.cbactivo);
        sw = 0;
    }

    public void Guardar(View view) {
        String codigoViaje, destino, cantidadPersonas, valor;
        codigoViaje = jetCodigoViaje.getText().toString();
        destino = jetDestino.getText().toString();
        cantidadPersonas = jetCantidadPersonas.getText().toString();
        valor = jetvalor.getText().toString();
        if (codigoViaje.isEmpty() || destino.isEmpty() ||
                cantidadPersonas.isEmpty() || valor.isEmpty()) {
            Toast.makeText(this, "Todos los datos son requeridos", Toast.LENGTH_SHORT).show();
            jetCodigoViaje.requestFocus();
        } else {
            SQLiteDatabase db = admin.getWritableDatabase();
            ContentValues registro = new ContentValues();
            registro.put("codigoviaje", codigoViaje);
            registro.put("ciudaddestino", destino);
            registro.put("cantidadpersonas", cantidadPersonas);
            registro.put("valor", Integer.parseInt(valor));
            if (sw == 0) {
                resp = db.insert("TblViaje", null, registro);
            } else {
                resp = db.update("TblViaje", registro, "codigoviaje='" + codigoViaje + "'", null);
                sw = 0;
            }
            if (resp > 0) {
                Toast.makeText(this, "Registro guardado", Toast.LENGTH_SHORT).show();
                Limpiar_campos();
            } else {
                Toast.makeText(this, "Error guardando registro", Toast.LENGTH_SHORT).show();
            }
            db.close();
        }
    }

    public void Consultar(View view) {
        codigoViaje = jetCodigoViaje.getText().toString();
        if (codigoViaje.isEmpty()) {
            Toast.makeText(this, "El codigo del viaje es requerido", Toast.LENGTH_SHORT).show();
            jetCodigoViaje.requestFocus();
        } else {
            SQLiteDatabase db = admin.getReadableDatabase();
            Cursor fila = db.rawQuery("select * from TblViaje where codigoviaje='" + codigoViaje + "'", null);
            if (fila.moveToNext()) {
                sw = 1;
                jetDestino.setText(fila.getString(1));
                jetCantidadPersonas.setText(fila.getString(2));
                jetvalor.setText(fila.getString(3));
                if (fila.getString(4).equals("si")) {
                    jcbactivo.setChecked(true);
                } else {
                    jcbactivo.setChecked(false);
                }
            } else {
                Toast.makeText(this, "Viaje no registrado", Toast.LENGTH_SHORT).show();
            }
            db.close();
        }
    }

    public void Anular(View view) {
        if (sw == 0) {
            Toast.makeText(this, "Primero debe consultar", Toast.LENGTH_SHORT).show();
            jetCodigoViaje.requestFocus();
        } else {
            SQLiteDatabase db = admin.getWritableDatabase();
            ContentValues registro = new ContentValues();
            registro.put("activo", "no");
            // String placa = "";
            resp = db.update("TblViaje", registro, "codigoviaje='" + codigoViaje + "'", null);
            if (resp > 0) {
                Toast.makeText(this, "Registro anulado", Toast.LENGTH_SHORT).show();
                Limpiar_campos();
                jcbactivo.setChecked(false);
            } else {
                Toast.makeText(this, "Error anulando registro", Toast.LENGTH_SHORT).show();
            }
            db.close();
        }
    }
    private void Limpiar_campos(){
        jetCodigoViaje.setText("");
        jetvalor.setText("");
        jetDestino.setText("");
        jetCantidadPersonas.setText("");
        jcbactivo.setChecked(false);
        jetCodigoViaje.requestFocus();
        sw=0;
    }
}